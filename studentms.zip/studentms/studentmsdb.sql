-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2023 at 04:25 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL,
  `AdminName` varchar(120) DEFAULT NULL,
  `UserName` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(2, 'Shahnoor Khan', 'Shahnoorkhan', 4354656561, 'Shahnoorsk@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '2023-12-11 19:20:40');

-- --------------------------------------------------------

--
-- Table structure for table `tblclass`
--

CREATE TABLE `tblclass` (
  `ID` int(5) NOT NULL,
  `ClassName` varchar(50) DEFAULT NULL,
  `Section` varchar(20) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblclass`
--

INSERT INTO `tblclass` (`ID`, `ClassName`, `Section`, `CreationDate`) VALUES
(1, '1', 'A', '2022-01-13 10:42:14'),
(2, '1', 'B', '2022-01-13 10:42:35'),
(3, '2', 'A', '2022-01-13 10:42:41'),
(4, '2', 'B', '2022-01-13 10:42:47'),
(5, '3', 'A', '2022-01-13 10:42:52');

-- --------------------------------------------------------

--
-- Table structure for table `tblstudent`
--

CREATE TABLE `tblstudent` (
  `ID` int(10) NOT NULL,
  `StudentName` varchar(200) DEFAULT NULL,
  `StudentEmail` varchar(200) DEFAULT NULL,
  `Gender` varchar(50) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `StuID` varchar(200) DEFAULT NULL,
  `FatherName` mediumtext DEFAULT NULL,
  `MotherName` mediumtext DEFAULT NULL,
  `Address` mediumtext DEFAULT NULL,
  `UserName` varchar(200) DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL,
  `Image` varchar(200) DEFAULT NULL,
  `DateofAdmission` timestamp NULL DEFAULT current_timestamp(),
  `class_id` int(11) DEFAULT NULL,
  `ContactNumber` varchar(15) DEFAULT NULL,
  `AlternateNumber` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblstudent`
--

INSERT INTO `tblstudent` (`ID`, `StudentName`, `StudentEmail`, `Gender`, `DOB`, `StuID`, `FatherName`, `MotherName`, `Address`, `UserName`, `Password`, `Image`, `DateofAdmission`, `class_id`, `ContactNumber`, `AlternateNumber`) VALUES
(10, 'Shahnoor Khan', 'shahnoor@gmail.com', 'Male', '2000-06-07', '23SP-086-CS', 'Azam Khan', 'Raziya Begum', '12 Bury Old Road, Manchester, M8 5EL', 'Shahnoorkhan', '7cdb42adc7eaa6b227315c7d03b26486', 'a741218d355772f15509a64b581e2c361702501187.jpg', '2023-12-13 20:59:47', 2, '+446792632627', '+449808800816'),
(11, 'Kishore Sharma', 'kishore@gmail.com', 'Male', '2019-01-05', '23SP-087-CS', 'Janak Sharma', 'Indra Devi', '346 Oak Street, London', 'Kishore_Sharma', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 06:23:33', 2, '+448666106507', '+443904130397'),
(12, 'John Doe', 'john.doe@gmail.com', 'Male', '2018-02-10', '23SP-088-CS', 'James Doe', 'Mary Doe', '123 Maple Street, New York', 'john_doe', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 04:45:00', 1, '+443522332770', '+445899272967'),
(13, 'Jane Smith', 'jane.smith@gmail.com', 'Female', '2017-07-22', '23SP-089-CS', 'Robert Smith', 'Emily Smith', '456 Pine Street, Los Angeles', 'jane_smith', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 05:30:00', 3, '+448929366831', '+446949015564'),
(14, 'Michael Johnson', 'michael.johnson@gmail.com', 'Male', '2016-04-15', '23SP-090-CS', 'David Johnson', 'Laura Johnson', '789 Cedar Street, Chicago', 'michael_johnson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 06:15:00', 3, '+447956977633', '+448937841783'),
(15, 'Eva Williams', 'eva.williams@gmail.com', 'Female', '2015-09-30', '23SP-091-CS', 'Daniel Williams', 'Olivia Williams', '567 Elm Street, San Francisco', 'eva_williams', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 07:00:00', 2, '+448182763224', '+447277856569'),
(16, 'Sophia Miller', 'sophia.miller@gmail.com', 'Female', '2018-05-12', '23SP-092-CS', 'William Miller', 'Emma Miller', '678 Walnut Street, Miami', 'sophia_miller', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 08:30:00', 1, '+443934454185', '+447838701529'),
(17, 'Oliver Brown', 'oliver.brown@gmail.com', 'Male', '2017-10-18', '23SP-093-CS', 'Christopher Brown', 'Ava Brown', '789 Pine Street, Seattle', 'oliver_brown', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 09:15:00', 1, '+447390145396', '+443434622700'),
(18, 'Lily Davis', 'lily.davis@gmail.com', 'Female', '2016-03-25', '23SP-094-CS', 'Matthew Davis', 'Sophia Davis', '890 Oak Street, Houston', 'lily_davis', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 10:00:00', 3, '+445002677622', '+444709520316'),
(19, 'Mason Wilson', 'mason.wilson@gmail.com', 'Male', '2015-08-08', '23SP-095-CS', 'Ryan Wilson', 'Isabella Wilson', '123 Cedar Street, Denver', 'mason_wilson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 11:45:00', 3, '+448539569022', '+448569284471'),
(20, 'Aria Taylor', 'aria.taylor@gmail.com', 'Female', '2014-01-20', '23SP-096-CS', 'Ethan Taylor', 'Madison Taylor', '456 Maple Street, Dallas', 'aria_taylor', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 12:30:00', 4, '+447227715595', '+444307248725'),
(21, 'Noah Garcia', 'noah.garcia@gmail.com', 'Male', '2013-06-14', '23SP-097-CS', 'Gabriel Garcia', 'Hannah Garcia', '789 Walnut Street, Phoenix', 'noah_garcia', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 13:15:00', 2, '+444704778835', '+441060215105'),
(22, 'Mia Hernandez', 'mia.hernandez@gmail.com', 'Female', '2012-11-28', '23SP-098-CS', 'Luis Hernandez', 'Avery Hernandez', '890 Pine Street, Atlanta', 'mia_hernandez', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 14:00:00', 1, '+443889642184', '+446267565913'),
(23, 'Ethan Martinez', 'ethan.martinez@gmail.com', 'Male', '2011-04-03', '23SP-099-CS', 'Carlos Martinez', 'Zoe Martinez', '123 Elm Street, San Diego', 'ethan_martinez', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 14:45:00', 2, '+449668903322', '+449541819179'),
(24, 'Isabella Robinson', 'isabella.robinson@gmail.com', 'Female', '2010-09-17', '23SP-100-CS', 'Nathan Robinson', 'Aria Robinson', '345 Cedar Street, Orlando', 'isabella_robinson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 15:30:00', 1, '+448702386234', '+444886473943'),
(25, 'Liam Walker', 'liam.walker@gmail.com', 'Male', '2009-02-09', '23SP-101-CS', 'Samuel Walker', 'Grace Walker', '567 Oak Street, Las Vegas', 'liam_walker', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 16:15:00', 1, '+448325211320', '+446966635079'),
(26, 'Aiden Harris', 'aiden.harris@gmail.com', 'Male', '2018-05-25', '23SP-102-CS', 'Andrew Harris', 'Ella Harris', '456 Pine Street, Boston', 'aiden_harris', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 17:00:00', 2, '+449857541741', '+448387803778'),
(27, 'Sophie Turner', 'sophie.turner@gmail.com', 'Female', '2019-11-12', '23SP-103-CS', 'David Turner', 'Sophia Turner', '789 Elm Street, Vancouver', 'sophie_turner', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 17:45:00', 3, '+442366393974', '+446668558844'),
(28, 'Henry White', 'henry.white@gmail.com', 'Male', '2020-04-08', '23SP-104-CS', 'Michael White', 'Mia White', '890 Oak Street, Sydney', 'henry_white', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 18:30:00', 1, '+446243612604', '+441212386797'),
(29, 'Emma Patel', 'emma.patel@gmail.com', 'Female', '2021-09-03', '23SP-105-CS', 'Aiden Patel', 'Lily Patel', '123 Maple Street, Toronto', 'emma_patel', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 19:15:00', 2, '+447331096480', '+443018322319'),
(30, 'Carter Kim', 'carter.kim@gmail.com', 'Male', '2022-02-18', '23SP-106-CS', 'Daniel Kim', 'Chloe Kim', '456 Cedar Street, Seoul', 'carter_kim', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 20:00:00', 3, '+443098322463', '+446436645664'),
(31, 'Harper Lee', 'harper.lee@gmail.com', 'Female', '2022-07-20', '23SP-107-CS', 'Jackson Lee', 'Ava Lee', '890 Pine Street, Paris', 'harper_lee', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 20:45:00', 1, '+442888261240', '+445131369517'),
(32, 'Owen Wilson', 'owen.wilson@gmail.com', 'Male', '2021-12-12', '23SP-108-CS', 'Tyler Wilson', 'Grace Wilson', '123 Oak Street, Berlin', 'owen_wilson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 21:30:00', 2, '+446992064171', '+449566212612'),
(33, 'Zoe Garcia', 'zoe.garcia@gmail.com', 'Female', '2021-05-28', '23SP-109-CS', 'Benjamin Garcia', 'Layla Garcia', '456 Elm Street, Madrid', 'zoe_garcia', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 22:15:00', 2, '+446854870856', '+445575716752'),
(34, 'Lucas Carter', 'lucas.carter@gmail.com', 'Male', '2020-10-04', '23SP-110-CS', 'Caleb Carter', 'Hazel Carter', '567 Pine Street, Tokyo', 'lucas_carter', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 23:00:00', 2, '+447313971498', '+449842707542'),
(35, 'Ava Brown', 'ava.brown@gmail.com', 'Female', '2019-03-19', '23SP-111-CS', 'Christopher Brown', 'Aria Brown', '789 Oak Street, Sydney', 'ava_brown', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 23:45:00', 4, '+447271623525', '+446829995305'),
(36, 'Mila Johnson', 'mila.johnson@gmail.com', 'Female', '2018-08-15', '23SP-112-CS', 'Ethan Johnson', 'Sophia Johnson', '456 Cedar Street, London', 'mila_johnson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 00:30:00', 1, '+442335106257', '+441185545680'),
(37, 'Elijah Smith', 'elijah.smith@gmail.com', 'Male', '2017-01-30', '23SP-113-CS', 'Daniel Smith', 'Ava Smith', '567 Elm Street, New York', 'elijah_smith', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 01:15:00', 2, '+448922409935', '+441055412945'),
(38, 'Avery Martinez', 'avery.martinez@gmail.com', 'Female', '2016-06-10', '23SP-114-CS', 'Liam Martinez', 'Zoe Martinez', '678 Oak Street, Los Angeles', 'avery_martinez', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 02:00:00', 2, '+448509835226', '+449382937605'),
(39, 'Logan Brown', 'logan.brown@gmail.com', 'Male', '2015-11-25', '23SP-115-CS', 'Cameron Brown', 'Emma Brown', '789 Pine Street, Chicago', 'logan_brown', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 02:45:00', 1, '+441385182655', '+448777100768'),
(40, 'Chloe Wilson', 'chloe.wilson@gmail.com', 'Female', '2014-04-05', '23SP-116-CS', 'Owen Wilson', 'Lily Wilson', '890 Elm Street, San Francisco', 'chloe_wilson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 03:30:00', 3, '+449729956183', '+442318478917'),
(41, 'Jack Carter', 'jack.carter@gmail.com', 'Male', '2013-09-20', '23SP-117-CS', 'Ryan Carter', 'Grace Carter', '123 Cedar Street, Vancouver', 'jack_carter', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 04:15:00', 2, '+442402526347', '+445057195290'),
(42, 'Aria Thomas', 'aria.thomas@gmail.com', 'Female', '2012-02-12', '23SP-118-CS', 'James Thomas', 'Ava Thomas', '456 Pine Street, Los Angeles', 'aria_thomas', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 05:00:00', 2, '+448078397715', '+445220403014'),
(43, 'Ethan Miller', 'ethan.miller@gmail.com', 'Male', '2011-07-28', '23SP-119-CS', 'Matthew Miller', 'Olivia Miller', '567 Maple Street, Miami', 'ethan_miller', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 05:45:00', 2, '+441866822235', '+443672902438'),
(44, 'Avery Robinson', 'avery.robinson@gmail.com', 'Female', '2010-12-05', '23SP-120-CS', 'Elijah Robinson', 'Isabella Robinson', '789 Oak Street, New York', 'avery_robinson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 06:30:00', 4, '+442764045794', '+442801521963'),
(45, 'Liam Davis', 'liam.davis@gmail.com', 'Male', '2009-05-19', '23SP-121-CS', 'Daniel Davis', 'Sophie Davis', '890 Elm Street, Chicago', 'liam_davis', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 07:15:00', 3, '+445715472740', '+441727981215'),
(46, 'Mila Johnson', 'mila_johnson@gmail.com', 'Female', '2008-10-02', '23SP-122-CS', 'Ethan Johnson', 'Emily Johnson', '123 Pine Street, San Francisco', 'mila_johnson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 08:00:00', 5, '+443717572692', '+448069469405'),
(47, 'Noah Taylor', 'noah.taylor@gmail.com', 'Male', '2007-03-18', '23SP-123-CS', 'Alexander Taylor', 'Zoe Taylor', '456 Cedar Street, Seattle', 'noah_taylor', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 08:45:00', 3, '+449194629256', '+441764738375'),
(48, 'Lily Wilson', 'lily.wilson@gmail.com', 'Female', '2006-08-31', '23SP-124-CS', 'Christopher Wilson', 'Chloe Wilson', '678 Elm Street, Dallas', 'lily_wilson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 09:30:00', 5, '+441239804412', '+449048072443'),
(49, 'Lucas Turner', 'lucas.turner@gmail.com', 'Male', '2005-02-13', '23SP-125-CS', 'Mason Turner', 'Layla Turner', '789 Pine Street, Atlanta', 'lucas_turner', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 10:15:00', 3, '+448046232914', '+441308695032'),
(50, 'Emma Brown', 'emma.brown@gmail.com', 'Female', '2004-07-27', '23SP-126-CS', 'Carter Brown', 'Sophia Brown', '890 Oak Street, Houston', 'emma_brown', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 11:00:00', 2, '+444129605595', '+446721943185'),
(51, 'Aiden Patel', 'aiden.patel@gmail.com', 'Male', '2003-12-11', '23SP-127-CS', 'Elijah Patel', 'Madison Patel', '123 Cedar Street, Denver', 'aiden_patel', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 11:45:00', 2, '+441220899448', '+445938667995'),
(52, 'Sophie Harris', 'sophie.harris@gmail.com', 'Female', '2003-05-26', '23SP-128-CS', 'Oliver Harris', 'Ava Harris', '456 Elm Street, Chicago', 'sophie_harris', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 12:30:00', 2, '+446030641939', '+442337206017'),
(53, 'Ethan Lee', 'ethan.lee@gmail.com', 'Male', '2002-11-09', '23SP-129-CS', 'Benjamin Lee', 'Emily Lee', '567 Pine Street, Los Angeles', 'ethan_lee', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 13:15:00', 4, '+443594104576', '+449589051374'),
(54, 'Olivia Robinson', 'olivia.robinson@gmail.com', 'Female', '2002-04-24', '23SP-130-CS', 'Lucas Robinson', 'Layla Robinson', '678 Oak Street, San Francisco', 'olivia_robinson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 14:00:00', 3, '+444012212263', '+447184346213'),
(55, 'Mason Davis', 'mason.davis@gmail.com', 'Male', '2001-10-08', '23SP-131-CS', 'Jackson Davis', 'Zoe Davis', '789 Elm Street, New York', 'mason_davis', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 14:45:00', 5, '+443885094582', '+447872434582'),
(56, 'Aria Garcia', 'aria.garcia@gmail.com', 'Female', '2001-03-23', '23SP-132-CS', 'Logan Garcia', 'Ava Garcia', '890 Pine Street, Miami', 'aria_garcia', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 15:30:00', 2, '+447706889470', '+444917143913'),
(57, 'Logan Taylor', 'logan.taylor@gmail.com', 'Male', '2000-08-06', '23SP-133-CS', 'Daniel Taylor', 'Sophia Taylor', '123 Cedar Street, Los Angeles', 'logan_taylor', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 16:15:00', 3, '+441465051464', '+442573825887'),
(58, 'Ava Wilson', 'ava.wilson@gmail.com', 'Female', '1999-12-21', '23SP-134-CS', 'Carter Wilson', 'Emma Wilson', '456 Elm Street, Chicago', 'ava_wilson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 17:00:00', 5, '+448473975349', '+444648399394'),
(59, 'Elijah Turner', 'elijah.turner@gmail.com', 'Male', '1999-05-07', '23SP-135-CS', 'Owen Turner', 'Lily Turner', '567 Oak Street, San Francisco', 'elijah_turner', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 17:45:00', 4, '+447820071231', '+445155158280'),
(60, 'Mia Brown', 'mia.brown@gmail.com', 'Female', '1998-10-20', '23SP-136-CS', 'Benjamin Brown', 'Aria Brown', '678 Pine Street, New York', 'mia_brown', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 18:30:00', 3, '+442315578015', '+446112415544'),
(61, 'Liam Patel', 'liam.patel@gmail.com', 'Male', '1998-03-06', '23SP-137-CS', 'Elijah Patel', 'Zoe Patel', '789 Oak Street, Miami', 'liam_patel', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 19:15:00', 1, '+443615343983', '+449739473592'),
(64, 'Shahveer Khan', 'shahveer312@gmail.com', 'Male', '2003-02-22', '23SP-138-CS', 'Azam Khan', 'Saba Azam', '78 Ashton Old Road, Manchester, M11 3NL', 'Shahveerk786', 'fc86e3f5517bdb3e500ff9843577bf35', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2023-12-13 21:52:32', 5, '+447851336316', '+443826111544');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblclass`
--
ALTER TABLE `tblclass`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblstudent`
--
ALTER TABLE `tblstudent`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `fk_class` (`class_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblclass`
--
ALTER TABLE `tblclass`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblstudent`
--
ALTER TABLE `tblstudent`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblstudent`
--
ALTER TABLE `tblstudent`
  ADD CONSTRAINT `fk_class` FOREIGN KEY (`class_id`) REFERENCES `tblclass` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
