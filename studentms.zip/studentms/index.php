<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StudentManagment</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <script src="https://kit.fontawesome.com/8097ade54d.js"></script>
   
   
    <link
  rel="stylesheet"
  href="https://unpkg.com/swiper@8/swiper-bundle.min.css"/>




  
    <link rel="stylesheet" href="index.css">
    

</head>
<body>
   
<!-- header section starts  -->

<header>

    <div id="menu" class="fas fa-bars"></div>

    <a href="#" class="logo"><i class="fas fa-user-graduate"></i><span> Student</span>Management</span></a>

    <nav class="navbar">
        <ul>
            <li><a class="active" href="#home">home</a></li>
            <li><a href="#about">about</a></li>
            <li><a href="#contact">contact</a></li>
        </ul>
    </nav>

    

</header>

<!-- header section ends -->

<!-- login form  -->

<div class="login-form">

    <form action="">
        <h3>Sign up</h3>
        <input type="text" placeholder="First Name" class="box">
        <input type="text" placeholder="Last Name" class="box">
        <input type="Email" placeholder=" Email" class="box">
        
        <input type="submit" class="btn" value="Submit">
        <i class="fas fa-times"></i>
    </form>

</div>

<!-- home section starts  -->

<section class="home" id="home">

    <h1 data-aos="fade-down">Student Management System</h1>
   
    <p> This school was started in 1980 and still growing in strength, covering all grades from pre-nursery to O-levels.</p>
    
    <a href="admin/login.php"><button class="btn" style="border: 2px solid white;">Login Teacher</button></a>
    <a href="user/login.php"><button class="btn" style="border: 2px solid white;">Login Student</button></a>
    

    

</section>


<section class="about" id="about">

    

    <div class="image" data-aos="fade-right">
    <img src="lab1.jpg" alt="">
    </div>

    <div class="content" data-aos="fade-left">
        <h3>Science Lab</h3>
        <p>Science is the pursuit and application of knowledge and understanding of the natural and social world following a systematic methodology based on evidence. Scientific methodology includes the following: Objective observation: Measurement and data (possibly although not necessarily using mathematics as a tool) Evidence.</p>
        <p>Scientific methodology includes the following: Objective observation: Measurement and data (possibly although not necessarily using mathematics as a tool) Evidence.</p>
       
    </div>

</section>

<section class="about1" id="about">

    <div class="content" data-aos="fade-left">
        <h3>Computer Lab</h3>
        <p>Computer labs provide the space to work on skills not directly related to classroom curriculum (especially for students without personal devices). After all, classroom time is limited, so teachers are often unable to provide instruction beyond the required material.</p>
        <p>The Computer Science Laboratory studies the logical foundations of scalable systems that are beyond the scope of traditional testing or simulation, and builds and applies efficient high-level tools for rigorous mechanical analysis.</p>
        
    </div>
    <div class="image" data-aos="fade-right">
    <img src="lab2.jpg" alt="">
    </div>

</section>

<!-- about section ends -->

<!-- course section starts  -->





<!-- course section ends -->

<!-- teacher section starts  -->

<section class="about2" id="teacher">

    <div class="image" data-aos="fade-right">
    <img src="lab3.jpg" alt="">
    </div>

    <div class="content" data-aos="fade-left">
        <h3>School Library</h3>
        <p>A place set apart to contain books, periodicals, and other material for reading, viewing, listening, study, or reference, as a room, set of rooms, or building where books may be read or borrowed. a public body organizing and maintaining such an establishment.</p>
        <p>A Library is a place where students and people interested in reading books visit very often. It constitutes several collections of books of variable genres to please the reader. </p>
       
    </div>

</section>



<section class="about3" id="teacher">

  
  <div class="content" id="contact" data-aos="fade-left">
      <h3>ADDRESS</h3>
      <p>43 Southlands Road Pont Aber United Kingdom</p>
      <h3>CONTACT</h3>
      <p>Phone no: 079 3466 4125 & 077 3025 9344</p>
     
  </div>

  <div class="image" data-aos="fade-right">
    <P><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2489.5014100204157!2d0.028071193485053464!3d51.39384104625652!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47d8aa598967f08b%3A0x572ec30b154dd37f!2s43%20Southlands%20Rd%2C%20Bromley%20BR2%209QR%2C%20UK!5e0!3m2!1sen!2s!4v1702314543008!5m2!1sen!2s" width="600" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></P>
</div>


</section>


      






<!-- teacher section ends -->

<!-- contact section starts  -->




<!-- contact section ends -->

<!-- footer section starts  -->

<footer>

    <div class="waves">
      <div class="wave" id="wave1"></div>
      <div class="wave" id="wave2"></div>
      <div class="wave" id="wave3"></div>
      <div class="wave" id="wave3"></div>
    </div>
    <ul class="social_icon">
      <li><a href="#"><ion-icon name="logo-facebook"></ion-icon> </a></li>
      <li><a href="#"><ion-icon name="logo-instagram"></ion-icon></a></li>
      <li><a href="#"><ion-icon name="logo-google-playstore"></ion-icon></a></li>
      <li><a href="#"><ion-icon name="logo-google"></ion-icon></a></li>
    </ul>

    <ul class="menufooter">
      <li><a href="#home">home</a></li>
            <li><a href="#about">about</a></li>
           
            
            <li><a href="#contact">contact</a></li>
      
    </ul>
    <p>
      © 2023 Student Management System All Rights Reserved.
    </p>

  </footer>

<!-- footer section ends -->









<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<script>
    AOS.init();
  </script>







<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>



<!-- jquery cdn link  -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- custom js file link  -->
<script src="script.js"></script>

<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>